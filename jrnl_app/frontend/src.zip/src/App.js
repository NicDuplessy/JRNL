import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import EntryIcon from './entry_icon.png';
import FulfillmentIcon from './fulfillment_icon.png';
import NavigationIcon from './navigation_icon.png';
import RequestIcon from './request_icon.png';
import AssetEntry from "./components/assetEntry";
import AssetRequest from "./components/assetRequest";
import AssetTracking from "./components/assetTracking";
import AssetFulfillment from "./components/assetFulfillment";
import JRNLLogo from './JRNL_No_text.png';

function Dashboard() {
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <img src={JRNLLogo} alt="JRNL Logo" className="dashboard-logo" />
        <h1 className="dashboard-title">JRNL Asset Management Solutions</h1>
      </div>
      <div className="dashboard-tiles-container">
        <DashboardTile icon={EntryIcon} label="ENTRY" to="/entry" />
        <DashboardTile icon={FulfillmentIcon} label="FULFILLMENT" to="/fulfillment" />
        <DashboardTile icon={NavigationIcon} label="TRACKING" to="/tracking" />
        <DashboardTile icon={RequestIcon} label="REQUEST" to="/request" />
      </div>
    </div>
  );
}

function DashboardTile({ icon, label, to }) {
  return (
    <Link to={to} className="dashboard-tile">
      <img src={icon} alt={label} />
      <p>{label}</p>
    </Link>
  );
}

function EntryView() {
  return (
    <div className="view entry-view">
      <img src={EntryIcon} alt="Entry" className="view-icon" />
      <h2>ENTRY</h2>
      <AssetEntry />
    </div>
  );
}

function RequestView() {
  return (
    <div className="view request-view">
      <img src={RequestIcon} alt="Request" className="view-icon" />
      <h2>REQUEST</h2>
      <AssetRequest />
    </div>
  );
}

function FulfillmentView() {
  return (
    <div className="view fulfillment-view">
      <img src={FulfillmentIcon} alt="Fulfillment" className="view-icon" />
      <h2>FULFILLMENT</h2>
      <AssetFulfillment />
    </div>
  );
}

function TrackingView() {
  return (
    <div className="view tracking-view">
      <img src={NavigationIcon} alt="Tracking" className="view-icon" />
      <h2>TRACKING</h2>
      <AssetTracking />
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/entry" element={<EntryView />} />
        <Route path="/request" element={<RequestView />} />
        <Route path="/fulfillment" element={<FulfillmentView />} />
        <Route path="/tracking" element={<TrackingView />} />
        <Route path="/" element={
          <div className="dashboard">
            <DashboardTile icon={EntryIcon} label="ENTRY" to="/entry" />
            <DashboardTile icon={FulfillmentIcon} label="FULFILLMENT" to="/fulfillment" />
            <DashboardTile icon={NavigationIcon} label="TRACKING" to="/tracking" />
            <DashboardTile icon={RequestIcon} label="REQUEST" to="/request" />
          </div>
        }/>
      </Routes>
    </Router>
  );
}

export default App;
